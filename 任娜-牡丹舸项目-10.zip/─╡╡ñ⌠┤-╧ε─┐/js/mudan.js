 /*轮播图*/
$(function(){
	var clone=$(".lunbo_ul li").first().clone();
    $(".lunbo_ul").append(clone);
    var size=$(".lunbo_ul li").length;
    $(".banner .num li").first().addClass("on");
    var i=0;
    
    function move(){
    	if(i == size){
    		$(".lunbo_ul").css({left : 0});
    		i=1;
    	}
    	if(i == -1){
    		$(".lunbo_ul").css({left : -(size-1)*1519.2});
    		i=size-2;
    	}
        $(".lunbo_ul").stop().animate({left : -i*1519.2},600)
        /*下面的num*/
        if (i == size - 1) {
            $(".banner .num li").eq(0).addClass("on").siblings().removeClass("on");
        } else {
            $(".banner .num li").eq(i).addClass("on").siblings().removeClass("on");
        }
    };
    
	/*自动轮播*/
    var t = setInterval(function () {
	    i++;
	    move();
    },2000);
	
    /*鼠标悬停事件*/
    $(".banner").hover(function () {
        clearInterval(t);//鼠标悬停时清除定时器
    }, function () {
        t = setInterval(function () {
	        i++;
	        move();
        }, 2000); //鼠标移出时开始定时器
    });

	/*鼠标滑入原点事件*/
    $(".banner .num li").hover(function () {
        var index = $(this).index();//获取当前索引值
        i = index;
        $(".banner .lunbo_ul").stop().animate({ left: -index * 1519.2 }, 600);
        $(this).addClass("on").siblings().removeClass("on");
    });
		
    /*向左按钮*/
    $(".banner .btn_l").click(function () {
        i--;
        move();
    })
    /*向右按钮*/
    $(".banner .btn_r").click(function () {
        i++;
        move();
    })
	/*二级菜单*/
	$(".head_ul1 li").mousemove(function(){
		$(this).children().eq(1).show();
	}).mouseout(function(){
		$(this).children().eq(1).hide();
	});
	$(".head_ul1_ul2 li").mouseover(function(){
		$(this).addClass("active").siblings().removeClass("active");
	});
	/*底部框*/
	$(".foot_ul1_li5").mousemove(function(){
		$(".foot_ul1_ul2").stop().slideDown("slow");
	}).mouseout(function(){
		$(".foot_ul1_ul2").stop().slideUp("slow");
	});
});